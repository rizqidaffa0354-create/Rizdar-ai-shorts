
import AIShortsEditor from "@/components/AIShortsEditor";

export default function Home() {
  return (
    <main className="min-h-screen bg-slate-100 text-slate-900 p-6">
      <AIShortsEditor />
    </main>
  );
}
