
import React, { useState, useRef } from "react";

export default function AIShortsEditor({ initialProject }) {
  const [title, setTitle] = useState(initialProject?.title || "My AI Short");
  const [template, setTemplate] = useState("motivasi");
  const [script, setScript] = useState(
    "Tulis hook 3-5 detik, lalu isi inti, lalu call-to-action singkat. Contoh: \nJangan menyerah — setiap kegagalan mendekatkanmu pada sukses. Klik follow untuk cerita selanjutnya!"
  );
  const [voice, setVoice] = useState("male_1");
  const [style, setStyle] = useState("cinematic");
  const [music, setMusic] = useState("uplifting_loop");
  const [duration, setDuration] = useState(18); // seconds
  const [previewSrc, setPreviewSrc] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [jobId, setJobId] = useState(null);
  const [jobs, setJobs] = useState([]);
  const videoRef = useRef(null);

  const TEMPLATES = [
    { id: "motivasi", name: "Motivasi 18s", description: "Hook kuat + CTA", defaultDuration: 18 },
    { id: "story", name: "Cerita Pendek 25s", description: "Narasi + klimaks", defaultDuration: 25 },
    { id: "fact", name: "Fakta Kilat 12s", description: "Satu fakta menarik cepat" , defaultDuration: 12},
    { id: "aesthetic", name: "Aesthetic 15s", description: "Visual slow + musik" , defaultDuration: 15},
  ];

  function applyTemplate(t) {
    setTemplate(t.id);
    setDuration(t.defaultDuration);
    const starters = {
      motivasi: "Halo! Ingin semangat tiap hari? Ini 3 langkah cepat untuk tetap produktif...",
      story: "Dulu ada seorang pemuda yang... (mulai dengan hook)",
      fact: "Tahukah kamu? 1 dari 3 orang...",
      aesthetic: "Visual lembut, teks singkat: nikmati momen kecil hari ini.",
    };
    setScript(starters[t.id]);
  }

  async function requestPreview() {
    setIsGenerating(true);
    try {
      await new Promise((r) => setTimeout(r, 800));
      const mockedPreview = '/mock-previews/placeholder-short.mp4';
      setPreviewSrc(mockedPreview);
    } catch (err) {
      console.error(err);
      alert('Preview gagal. Cek koneksi atau lihat logs.');
    } finally {
      setIsGenerating(false);
    }
  }

  async function submitFullRender() {
    setIsGenerating(true);
    try {
      await new Promise((r) => setTimeout(r, 1200));
      const id = 'job_' + Math.random().toString(36).slice(2, 9);
      const newJob = { id, title, status: 'QUEUED', createdAt: new Date().toISOString() };
      setJobs((s) => [newJob, ...s]);
      setJobId(id);
      pollJob(id);
    } catch (err) {
      console.error(err);
      alert('Submit render gagal.');
    } finally {
      setIsGenerating(false);
    }
  }

  function pollJob(id) {
    let steps = ["RUNNING", "ASSEMBLING", "UPLOADING", "DONE"];
    let idx = 0;
    const interval = setInterval(() => {
      idx++;
      setJobs((prev) => prev.map(j => j.id === id ? { ...j, status: steps[Math.min(idx, steps.length-1)] } : j));
      if (idx >= steps.length) {
        clearInterval(interval);
        setJobs((prev) => prev.map(j => j.id === id ? { ...j, outputUrl: `/outputs/${id}.mp4` } : j));
      }
    }, 1500);
  }

  function fmtSec(s) {
    return `${s}s`;
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="bg-white shadow-sm sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <div className="text-xl font-semibold">AI Shorts Studio</div>
              <div className="hidden md:flex gap-2 text-sm text-slate-500">
                <span className="px-2 py-1 rounded-md bg-slate-100">Templates</span>
                <span className="px-2 py-1 rounded-md">Presets</span>
                <span className="px-2 py-1 rounded-md">Jobs</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-sm text-slate-500">Signed in as <strong className="ml-1">you@example.com</strong></div>
              <button
                onClick={requestPreview}
                disabled={isGenerating}
                className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md shadow-sm hover:bg-indigo-700 disabled:opacity-60"
              >
                Preview
              </button>
              <button
                onClick={submitFullRender}
                disabled={isGenerating}
                className="inline-flex items-center px-4 py-2 bg-emerald-600 text-white rounded-md shadow-sm hover:bg-emerald-700 disabled:opacity-60"
              >
                {isGenerating ? 'Generating...' : 'Render Full'}
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-12 gap-6">
          <section className="col-span-12 lg:col-span-3 bg-white rounded-lg shadow p-4">
            <h3 className="text-lg font-medium">Script & Templates</h3>
            <p className="text-sm text-slate-500 mt-1">Pilih template, edit script, atau generate otomatis.</p>

            <div className="mt-4 space-y-3">
              <label className="block text-sm font-medium">Project title</label>
              <input
                className="w-full rounded-md border px-3 py-2"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />

              <label className="block text-sm font-medium mt-2">Templates</label>
              <div className="grid gap-2">
                {TEMPLATES.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => applyTemplate(t)}
                    className={`text-left p-2 border rounded-md ${template === t.id ? 'border-indigo-500 bg-indigo-50' : 'border-transparent hover:border-slate-200'}`}>
                    <div className="font-medium">{t.name}</div>
                    <div className="text-xs text-slate-500">{t.description}</div>
                  </button>
                ))}
              </div>

              <label className="block text-sm font-medium mt-3">Script</label>
              <textarea
                rows={8}
                className="w-full rounded-md border px-3 py-2 text-sm"
                value={script}
                onChange={(e) => setScript(e.target.value)}
              />

              <button
                onClick={() => {
                  setScript((s) => s + '\n\n[Rewritten to be punchier]');
                }}
                className="w-full mt-2 px-3 py-2 rounded-md border bg-slate-50 text-sm"
              >
                Make punchier (AI)
              </button>

            </div>
          </section>

          <section className="col-span-12 lg:col-span-6 bg-white rounded-lg shadow p-4 flex flex-col">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-lg font-medium">Preview</h3>
                <p className="text-sm text-slate-500">Low-res preview sebelum full render. Gunakan Preview untuk cek timing.</p>
              </div>
              <div className="text-sm text-slate-500">Duration: <strong>{fmtSec(duration)}</strong></div>
            </div>

            <div className="mt-4 flex-1 grid grid-rows-2 gap-3">
              <div className="row-span-2 bg-black rounded-md flex items-center justify-center overflow-hidden">
                {previewSrc ? (
                  <video ref={videoRef} src={previewSrc} controls className="w-full h-full object-cover" />
                ) : (
                  <div className="text-center text-white px-6">
                    <div className="text-xl font-medium mb-2">Preview kosong</div>
                    <div className="text-sm opacity-80">Klik "Preview" untuk generate low-res preview cepat</div>
                  </div>
                )}
              </div>

              <div className="bg-slate-50 rounded-md p-3 text-sm">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Timeline</div>
                  <div className="text-xs text-slate-400">Auto-generated scenes: 3</div>
                </div>
                <div className="mt-2 grid grid-cols-3 gap-2 text-xs">
                  <div className="p-2 bg-white rounded">0–5s<br/><span className="text-slate-400">Hook</span></div>
                  <div className="p-2 bg-white rounded">5–14s<br/><span className="text-slate-400">Body</span></div>
                  <div className="p-2 bg-white rounded">14–18s<br/><span className="text-slate-400">CTA</span></div>
                </div>

                <div className="mt-3">
                  <label className="block text-xs text-slate-500">Subtitle preview</label>
                  <div className="mt-1 text-sm text-slate-700 bg-white p-2 rounded">{script.split('\n').slice(0,3).join(' — ')}</div>
                </div>
              </div>
            </div>

          </section>

          <aside className="col-span-12 lg:col-span-3 bg-white rounded-lg shadow p-4">
            <h3 className="text-lg font-medium">Settings</h3>
            <p className="text-sm text-slate-500 mt-1">Pilih suara, style, musik, dan format export.</p>

            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-sm font-medium">Voice</label>
                <select value={voice} onChange={(e) => setVoice(e.target.value)} className="mt-1 w-full rounded-md border px-3 py-2 text-sm">
                  <option value="male_1">Male - Natural (recommended)</option>
                  <option value="female_1">Female - Warm</option>
                  <option value="neutral_1">Neutral - TTS Lite</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium">Style / Visual</label>
                <select value={style} onChange={(e) => setStyle(e.target.value)} className="mt-1 w-full rounded-md border px-3 py-2 text-sm">
                  <option value="cinematic">Cinematic</option>
                  <option value="fast_cut">Fast Cut (viral)</option>
                  <option value="aesthetic">Aesthetic</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium">Music</label>
                <select value={music} onChange={(e) => setMusic(e.target.value)} className="mt-1 w-full rounded-md border px-3 py-2 text-sm">
                  <option value="uplifting_loop">Uplifting Loop (default)</option>
                  <option value="dramatic_swell">Dramatic Swell</option>
                  <option value="calm_pads">Calm Pads</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium">Duration</label>
                <input type="range" min={6} max={60} value={duration} onChange={(e) => setDuration(parseInt(e.target.value))} className="w-full mt-2" />
                <div className="text-xs text-slate-500 mt-1">{fmtSec(duration)}</div>
              </div>

              <div>
                <label className="block text-sm font-medium">Output Format</label>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  <button className="p-2 border rounded text-sm">MP4 (H264)</button>
                  <button className="p-2 border rounded text-sm">WEBM (AV1)</button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium">Advanced</label>
                <div className="mt-2 text-xs text-slate-500">Watermark: <strong className="text-slate-700 ml-1">Off (Premium removes)</strong></div>
                <div className="mt-2 text-xs text-slate-500">Subtitle style: Default</div>
              </div>

              <div className="mt-3">
                <button onClick={requestPreview} className="w-full px-3 py-2 rounded-md bg-indigo-600 text-white">Quick Preview</button>
                <button onClick={submitFullRender} className="w-full mt-2 px-3 py-2 rounded-md bg-emerald-600 text-white">Start Full Render</button>
              </div>

            </div>

          </aside>

          <section className="col-span-12 bg-white rounded-lg shadow p-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Job History</h3>
              <div className="text-sm text-slate-500">Showing last {jobs.length} jobs</div>
            </div>

            <div className="mt-3 overflow-x-auto">
              <table className="w-full text-sm table-auto">
                <thead>
                  <tr className="text-left text-xs text-slate-500">
                    <th className="py-2">Job ID</th>
                    <th>Title</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Output</th>
                  </tr>
                </thead>
                <tbody>
                  {jobs.map((j) => (
                    <tr key={j.id} className="border-t">
                      <td className="py-2 font-mono text-xs">{j.id}</td>
                      <td>{j.title}</td>
                      <td>{j.status}</td>
                      <td className="text-xs text-slate-400">{new Date(j.createdAt).toLocaleString()}</td>
                      <td className="text-sm">
                        {j.outputUrl ? (
                          <a href={j.outputUrl} className="text-indigo-600 underline" target="_blank" rel="noreferrer">Download</a>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

        </div>
      </main>

      <footer className="text-center text-xs text-slate-400 py-6">AI Shorts Studio • built with Tailwind • prototype UI</footer>
    </div>
  );
}
